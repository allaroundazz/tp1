public class DagingAyam extends BarangDagangan {
    public DagingAyam(int harga) {
        setHarga(harga);
    }

    
}
