public class Rendang extends BarangDagangan {
    public Rendang(int harga) {
        setHarga(harga);
    }
    
}
