public abstract class BarangDagangan {
    private int harga = 0;

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }



}