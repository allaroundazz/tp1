public interface BisaDimakan {
    public abstract void caraMakan();
}